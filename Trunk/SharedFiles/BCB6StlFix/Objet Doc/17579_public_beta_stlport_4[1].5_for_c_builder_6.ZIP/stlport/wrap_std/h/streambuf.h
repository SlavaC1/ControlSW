//*TY 02/11/2000 - added missing header file

# include _STLP_NATIVE_OLD_STREAMS_HEADER(iostream.h)

# if defined (_STLP_USE_OWN_NAMESPACE)
_STLP_BEGIN_NAMESPACE
# include <using/h/streambuf.h>
_STLP_END_NAMESPACE
# endif /* _STLP_USE_OWN_NAMESPACE */
