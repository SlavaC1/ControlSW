#pragma warning( disable : 4146 ) // unary minus applied to unsigned type
#pragma warning( disable : 4244 ) // arithmetic conversion - possible loss of data
#pragma warning( disable : 4290 ) // c++ exception specification ignored

// dwa 1/28/00 - actually I think this may indicate real bugs. We should look
// into these
#pragma warning( disable : 4018 ) // signed/unsigned mismatch
#pragma warning( disable : 4251 ) // DLL interface needed



