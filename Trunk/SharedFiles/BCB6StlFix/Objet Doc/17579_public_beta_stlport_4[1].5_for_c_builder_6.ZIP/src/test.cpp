#include <iostream>

int main()
{
  using namespace std;
  cerr<<"Hello World"<<endl;
}
